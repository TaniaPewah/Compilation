//
// Created by tt on 5/22/2020.
//

#ifndef HW3_PARSER_HPP
#define HW3_PARSER_HPP
#include <iostream>
using namespace std;

class Node{
    public:
    int lineno;

    Node(int lineno) : lineno(lineno) {};
};

class IdNode: public Node{
    
    public:
    string name;
    string type;

    Node( string name, string type ) : name(name), type(type) {
        cout << "node created ~~~~~~~~~~~~~~~~~~~~~" << name << endl;
    };
};

class Num: public Node{
public:
    Num(const string& name, const string& type ) : Node(name, type) {};
};


#define YYSTYPE Node*
#endif //HW3_PARSER_HPP
